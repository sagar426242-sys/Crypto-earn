
package com.cryptoearn.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

data class Coin(val symbol:String,val name:String,val price:Double,val change:Double)
data class Tx(val type:String,val asset:String,val amount:String,val status:String,val time:String)

class MainActivity:Activity(){
 private lateinit var body:LinearLayout
 private val bg=Color.rgb(7,10,17); private val card=Color.rgb(18,24,35); private val purple=Color.rgb(124,92,252)
 private val coins=listOf(
  Coin("BTC","Bitcoin",112480.20,2.31),Coin("ETH","Ethereum",4820.15,1.82),
  Coin("SOL","Solana",214.72,4.16),Coin("BNB","BNB",782.40,.94),Coin("USDT","Tether",1.0,.01))
 private val bal=mutableMapOf("USDT" to 8250.0,"BTC" to .0184,"ETH" to .74,"SOL" to 4.2,"BNB" to .8)
 private val tx=mutableListOf<Tx>()
 private val prefs by lazy{getSharedPreferences("ce",Context.MODE_PRIVATE)}

 override fun onCreate(b:Bundle?){super.onCreate(b);load();home()}
 private fun load(){bal.keys.toList().forEach{k->prefs.getString(k,null)?.toDoubleOrNull()?.let{bal[k]=it}}}
 private fun save(){val e=prefs.edit();bal.forEach{(k,v)->e.putString(k,v.toString())};e.apply()}
 private fun now()=SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(Date())

 private fun shell():LinearLayout{
  val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setBackgroundColor(bg)
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL;body.setPadding(18,20,18,20)
  val sc=ScrollView(this);sc.addView(body);r.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
  val nav=LinearLayout(this);nav.setBackgroundColor(card)
  arrayOf("⌂\nHome","▦\nMarkets","✦\nEarn","◈\nWallet","☻\nProfile").forEachIndexed{i,t->
   val v=TextView(this);v.text=t;v.gravity=17;v.setTextColor(Color.LTGRAY);v.textSize=12f;v.setPadding(0,10,0,8)
   v.setOnClickListener{when(i){0->home();1->markets();2->earn();3->wallet();4->profile()}}
   nav.addView(v,LinearLayout.LayoutParams(0,64,1f))
  };r.addView(nav);return r
 }
 private fun reset(){setContentView(shell())}
 private fun add(t:String,s:Float=16f,c:Int=Color.WHITE){body.addView(TextView(this).apply{text=t;textSize=s;setTextColor(c);setPadding(0,5,0,5)})}
 private fun box(t:String){val v=TextView(this).apply{text=t;textSize=16f;setTextColor(Color.WHITE);setPadding(18,18,18,18);background=GradientDrawable().apply{setColor(card);cornerRadius=22f}};body.addView(v,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})}
 private fun btn(t:String,f:()->Unit){val b=Button(this);b.text=t;b.setTextColor(Color.WHITE);b.background=GradientDrawable().apply{setColor(purple);cornerRadius=18f};b.setOnClickListener{f()};body.addView(b,LinearLayout.LayoutParams(-1,56).apply{setMargins(0,6,0,6)})}
 private fun input(h:String):EditText{val e=EditText(this);e.hint=h;e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setPadding(14,0,14,0);body.addView(e,LinearLayout.LayoutParams(-1,56).apply{setMargins(0,5,0,5)});return e}

 private fun home(){
  reset();add("Crypto Earn",29f);add("Welcome back 👋",14f,Color.GRAY)
  val total=bal["USDT"]!!+bal["BTC"]!!*coins[0].price+bal["ETH"]!!*coins[1].price+bal["SOL"]!!*coins[2].price+bal["BNB"]!!*coins[3].price
  box("TOTAL BALANCE\n$${"%,.2f".format(total)}\n\n24H P/L   +$184.20  (+1.49%)")
  btn("＋  Deposit"){deposit()};btn("↗  Withdraw"){withdraw()}
  add("Assets",20f);box("USDT   ${"%,.2f".format(bal["USDT"])}\nBTC    ${"%.6f".format(bal["BTC"])}\nETH    ${"%.5f".format(bal["ETH"])}")
  add("Trending",20f);coins.take(4).forEach{box("${it.symbol}  ${it.name}\n$${"%,.2f".format(it.price)}   ${it.change}%")}
  add("Security reminder",18f);box("Demo mode is active. Real funds are not processed.")
 }

 private fun markets(){
  reset();add("Markets",29f);add("Crypto prices",14f,Color.GRAY)
  val e=input("Search BTC / ETH / SOL");btn("Search"){marketResults(e.text.toString())}
  marketResults("")
 }
 private fun marketResults(q:String){
  val old=body.children.filterIsInstance<EditText>().firstOrNull()
  coins.filter{q.isBlank()||it.symbol.contains(q.uppercase())||it.name.uppercase().contains(q.uppercase())}.forEach{c->
   box("${c.symbol}  ${c.name}\n$${"%,.2f".format(c.price)}   ${itPct(c.change)}")
   btn("View ${c.symbol}"){coin(c.symbol)}
  }
 }
 private fun itPct(x:Double)="${if(x>=0) "+" else ""}${"%.2f".format(x)}%"
 private fun coin(symbol:String){
  reset();val c=coins.first{it.symbol==symbol};add("${c.symbol} / USD",29f);add(c.name,14f,Color.GRAY)
  box("PRICE\n$${"%,.2f".format(c.price)}\n24H  ${itPct(c.change)}")
  box("1H    1D    1W    1M    1Y\n\n▁▂▃▂▅▆▅▇▆▇▇▆▇▉▇▆▇▅▇▆\n\nCandlestick-style demo chart")
  box("24H High  $${"%,.2f".format(c.price*1.03)}\n24H Low   $${"%,.2f".format(c.price*.97)}\nVolume    Demo data")
  btn("Buy ${c.symbol}"){trade(c.symbol)};btn("Sell ${c.symbol}"){trade(c.symbol)}
 }
 private fun trade(symbol:String){
  reset();val c=coins.first{it.symbol==symbol};add("Trade ${c.symbol}",29f);add("Spot demo trading",14f,Color.GRAY)
  box("Current price\n$${"%,.2f".format(c.price)}\n\n▁▂▃▂▅▆▅▇▆▇▇▆▇▉▇▆▇")
  val a=input("USDT amount")
  btn("BUY ${c.symbol}"){execute("BUY",c,a.text.toString().toDoubleOrNull()?:0.0)}
  btn("SELL ${c.symbol}"){execute("SELL",c,a.text.toString().toDoubleOrNull()?:0.0)}
  box("Available: ${"%.6f".format(bal[c.symbol]?:0.0)} ${c.symbol}\nUSDT: ${"%.2f".format(bal["USDT"]?:0.0)}")
 }
 private fun execute(side:String,c:Coin,a:Double){
  if(a<=0){toast("Enter a valid amount");return};val q=a/c.price
  if(side=="BUY"){
   if(a>bal["USDT"]!!){toast("Insufficient demo USDT");return}
   bal["USDT"] = bal["USDT"]!!-a;bal[c.symbol]=(bal[c.symbol]?:0.0)+q
  }else{
   if(q>(bal[c.symbol]?:0.0)){toast("Insufficient demo ${c.symbol}");return}
   bal[c.symbol]=bal[c.symbol]!!-q;bal["USDT"]=bal["USDT"]!!+a
  }
  save();tx.add(Tx("$side ${c.symbol}",c.symbol,"${"%.8f".format(q)} ${c.symbol}","COMPLETED",now()));confirmation(side,c,a,q)
 }
 private fun confirmation(side:String,c:Coin,a:Double,q:Double){
  reset();add("Order Successful",29f);box("${side} ${c.symbol}\n\nPrice  $${"%,.2f".format(c.price)}\nQuantity  ${"%.8f".format(q)} ${c.symbol}\nValue  $${"%.2f".format(a)} USDT\nStatus  COMPLETED")
  btn("View Orders"){orders()};btn("Back Home"){home()}
 }

 private fun earn(){
  reset();add("Earn",29f);add("Flexible demo products",14f,Color.GRAY)
  earnCard("USDT Earn","8.0%","Flexible","10 USDT");earnCard("BTC Earn","3.5%","30 days","0.001 BTC");earnCard("ETH Earn","4.2%","60 days","0.01 ETH")
  box("⚠ APY is an estimate for demonstration. No guaranteed returns.")
 }
 private fun earnCard(asset:String,apy:String,term:String,min:String){
  box("$asset\nEstimated APY  $apy\n$term • Minimum $min");btn("Start Earning"){toast("Demo position created")}
 }
 private fun wallet(){
  reset();add("Wallet",29f);add("Portfolio assets",14f,Color.GRAY)
  bal.forEach{(k,v)->box("$k\n${"%.8f".format(v)} $k")}
  btn("Deposit"){deposit()};btn("Withdraw"){withdraw()};btn("Transaction History"){transactions()}
 }
 private fun deposit(){
  reset();add("Deposit",29f);add("Demo deposit",14f,Color.GRAY);box("Select asset: USDT\nNetwork: Demo Network\n\nAddress\nCE-DEMO-ADDRESS-7F42\n\nQR\n▣ ▣ ▣\n▣ ▣ ▣")
  val a=input("USDT amount");btn("Confirm Deposit"){val n=a.text.toString().toDoubleOrNull()?:0.0;if(n<=0){toast("Enter amount");return@btn};bal["USDT"]=bal["USDT"]!!+n;save();tx.add(Tx("DEPOSIT","USDT","${"%.2f".format(n)} USDT","COMPLETED",now()));toast("Demo deposit added");wallet()}
 }
 private fun withdraw(){
  reset();add("Withdraw",29f);add("Demo withdrawal",14f,Color.GRAY);box("Asset: USDT\nAvailable ${"%.2f".format(bal["USDT"])} USDT")
  val ad=input("Wallet address");val a=input("Amount USDT");box("Network fee  1.00 USDT\nMinimum demo withdrawal  2 USDT")
  btn("Confirm Withdrawal"){val n=a.text.toString().toDoubleOrNull()?:0.0;if(ad.text.isBlank()||n<2||n>bal["USDT"]!!){toast("Check address and amount");return@btn};bal["USDT"]=bal["USDT"]!!-n;save();tx.add(Tx("WITHDRAW","USDT","${"%.2f".format(n)} USDT","PENDING",now()));toast("Demo withdrawal submitted");transactions()}
 }
 private fun transactions(){
  reset();add("Transactions",29f);if(tx.isEmpty())box("No transactions yet.") else tx.asReversed().forEach{x->box("${x.type}\n${x.amount}\n${x.status} • ${x.time}")}
 }
 private fun orders(){transactions()}
 private fun profile(){
  reset();add("Profile",29f);add("Account",14f,Color.GRAY);box("Demo User\nuser@example.com");box("KYC\nNot submitted");box("Security\nPassword • 2FA");btn("Settings"){settings()};btn("Help & Support"){support()};btn("Logout"){login()}
 }
 private fun settings(){reset();add("Settings",29f);box("Notifications\nPrice alerts • Orders • Earn rewards");box("Security\nDemo mode enabled");box("Language\nEnglish / Hindi");btn("Reset Demo Data"){prefs.edit().clear().apply();bal["USDT"]=8250.0;bal["BTC"]=.0184;bal["ETH"]=.74;bal["SOL"]=4.2;bal["BNB"]=.8;tx.clear();toast("Reset complete");home()}}
 private fun support(){reset();add("Help & Support",29f);box("Frequently Asked Questions\n• Deposits\n• Withdrawals\n• Trading\n• Earn");input("Describe your issue");btn("Submit Demo Ticket"){toast("Demo ticket submitted")}}
 private fun login(){reset();add("Crypto Earn",31f);add("Secure account access",14f,Color.GRAY);box("Demo environment");input("Email or mobile");input("Password");btn("Login"){home()};btn("Create Account"){home()};add("By continuing you agree to the demo Terms & Privacy.",12f,Color.GRAY)}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
