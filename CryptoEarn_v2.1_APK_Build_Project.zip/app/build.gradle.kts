plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.cryptoearn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cryptoearn.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "2.1"
    }
}
