# Crypto Earn v2.0 — Full Demo App

This release combines the previous demo versions into a more complete local Android demo:
- Home dashboard and portfolio
- Markets + search
- Coin details + chart preview
- Multi-coin demo spot trading
- Buy/sell confirmation
- Wallet
- Deposit/withdraw demo flows
- Transaction history
- Earn products
- Profile, settings, support
- Local demo balance persistence

Important: this is NOT a production crypto exchange. It does not custody funds, execute blockchain transactions, or guarantee returns. Production deployment requires a secure backend, wallet infrastructure, KYC/AML and applicable regulatory compliance.
